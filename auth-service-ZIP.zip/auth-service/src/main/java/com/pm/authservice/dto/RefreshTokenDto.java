package com.pm.authservice.dto;

import lombok.Data;

@Data
public class RefreshTokenDto {

    private String refreshToken;

}
