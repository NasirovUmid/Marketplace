package com.pm.authservice.enums;

public enum UserEventType {

    USER_CREATED,
    USER_UPDATED,
    USER_DELETED
}
